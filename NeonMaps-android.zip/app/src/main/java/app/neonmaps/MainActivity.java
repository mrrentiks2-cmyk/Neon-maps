package app.neonmaps;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final int REQ_LOC = 11;

    WebView web;
    WebViewAssetLoader loader;
    Geo geo;
    Speech tts;
    TileStore store;
    Regions regions;
    SharedPreferences prefs;
    final Handler ui = new Handler(Looper.getMainLooper());
    volatile String pendingIntent = "";
    volatile int insetTop = 0, insetBottom = 0;
    volatile boolean pageReady;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("app", MODE_PRIVATE);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(0xFF0B0A12);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        w.getDecorView().setOnApplyWindowInsetsListener((v, ins) -> {
            insetTop = ins.getSystemWindowInsetTop();
            insetBottom = 0;
            return v.onApplyWindowInsets(ins);
        });

        NavService.activity = new java.lang.ref.WeakReference<>(this);
        Geo.Out out = this::emit;
        store = new TileStore(this);
        regions = new Regions(this, store, out);
        geo = new Geo(this, out);
        tts = new Speech(this, out);

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);
        web = new WebView(this);
        web.setBackgroundColor(0xFF07080D);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " NeonMaps/" + BuildConfig.VERSION_NAME);
        loader = new WebViewAssetLoader.Builder().setDomain(HOST).addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path = u.getPath();
                if ("/__t".equals(path)) return store.serve(u.getQueryParameter("u"));
                if ("/__h".equals(path)) return store.proxy(u.getQueryParameter("u"));
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) { pageReady = true; }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // the map's GPU process died (low memory): rebuild the screen instead of crashing
                ui.post(MainActivity.this::recreate);
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "A");
        takeIntent(getIntent());
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    /** events to the page: window.__mEvent({...}) */
    void emit(JSONObject e) {
        final String js = "window.__mEvent && window.__mEvent(" + JSONObject.quote(e.toString()) + ")";
        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    void emitSimple(String type) { try { emit(new JSONObject().put("type", type)); } catch (Exception ignored) { } }

    private void takeIntent(Intent i) {
        if (i == null) return;
        String t = null;
        if (Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) t = i.getData().toString();
        else if (Intent.ACTION_SEND.equals(i.getAction())) t = i.getStringExtra(Intent.EXTRA_TEXT);
        if (t != null && !t.isEmpty()) pendingIntent = t;
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        takeIntent(i);
        if (!pendingIntent.isEmpty()) emitSimple("intent");
    }

    @Override
    protected void onResume() {
        super.onResume();
        geo.resume();
        if (web != null) web.onResume();
        emitSimple("resume");
    }

    @Override
    protected void onPause() {
        geo.pause();
        emitSimple("pause");
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        NavService.stop(this);
        geo.keepAlive = false;
        geo.stop();
        tts.shutdown();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.__mBack ? window.__mBack() : false", v -> {
            if (!"true".equals(v)) moveTaskToBack(true);
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_LOC) {
            boolean ok = geo.permitted();
            try { emit(new JSONObject().put("type", "perm").put("what", "loc").put("granted", ok)); } catch (Exception ignored) { }
        }
    }

    void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            ui.post(() -> Toast.makeText(this, "Нет приложения, чтобы открыть ссылку", Toast.LENGTH_SHORT).show());
        }
    }

    float density() { return getResources().getDisplayMetrics().density; }

    final class Bridge {
        @JavascriptInterface
        public String insets() {
            int top = insetTop;
            if (top == 0) {
                int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
                if (id > 0) top = getResources().getDimensionPixelSize(id);
            }
            try { return new JSONObject().put("top", Math.round(top / density())).put("bottom", Math.round(insetBottom / density())).toString(); } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void setStatusLight(boolean lightMap) {
            ui.post(() -> {
                View d = getWindow().getDecorView();
                int f = d.getSystemUiVisibility();
                f = lightMap ? f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                d.setSystemUiVisibility(f);
            });
        }

        @JavascriptInterface
        public String locPerm() {
            if (geo.permitted()) return "granted";
            boolean asked = prefs.getBoolean("askedLoc", false);
            if (!asked || shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) return "ask";
            return "denied";
        }

        @JavascriptInterface
        public void askLoc() {
            ui.post(() -> {
                boolean asked = prefs.getBoolean("askedLoc", false);
                if (asked && !shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION) && !geo.permitted()) {
                    // "don't ask again": the system dialog will not appear any more
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                    try { startActivity(i); } catch (Exception ignored) { }
                    return;
                }
                prefs.edit().putBoolean("askedLoc", true).apply();
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            });
        }

        @JavascriptInterface public void locStart(boolean precise) { ui.post(() -> geo.start(precise)); }
        @JavascriptInterface public void locStop() { ui.post(() -> geo.stop()); }
        @JavascriptInterface public boolean gpsOn() { return geo.enabled(); }

        @JavascriptInterface
        public void openLocSettings() {
            ui.post(() -> { try { startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); } catch (Exception ignored) { } });
        }

        @JavascriptInterface public void compass(boolean on) { ui.post(() -> geo.compass(on)); }

        @JavascriptInterface
        public void navOn(boolean on, String text) {
            ui.post(() -> {
                geo.keepAlive = on;
                if (!on) { NavService.stop(MainActivity.this); return; }
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !prefs.getBoolean("askedNotif", false)) {
                    prefs.edit().putBoolean("askedNotif", true).apply();
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 12);
                }
                if (geo.permitted()) NavService.start(MainActivity.this, text);
            });
        }

        @JavascriptInterface public void navText(String text) { NavService.update(MainActivity.this, text); }

        /** follow short links (yandex.ru/maps/-/…, go.2gis.com/…) to the full URL with coordinates */
        @JavascriptInterface
        public void resolveUrl(String id, String url) {
            new Thread(() -> {
                String fin = url;
                try {
                    for (int i = 0; i < 6 && fin.startsWith("https://"); i++) {
                        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(fin).openConnection();
                        c.setInstanceFollowRedirects(false);
                        c.setRequestProperty("User-Agent", TileStore.UA);
                        c.setConnectTimeout(8000);
                        c.setReadTimeout(8000);
                        int code = c.getResponseCode();
                        String loc = c.getHeaderField("Location");
                        c.disconnect();
                        if (code >= 300 && code < 400 && loc != null) fin = new java.net.URL(new java.net.URL(fin), loc).toString();
                        else break;
                    }
                } catch (Exception ignored) { }
                try { emit(new JSONObject().put("type", "resolved").put("id", id).put("url", fin)); } catch (Exception ignored) { }
            }).start();
        }
        @JavascriptInterface public void say(String text) { tts.say(text); }
        @JavascriptInterface public void sayStop() { tts.stop(); }
        @JavascriptInterface public String ttsOk() { return tts.status(); }

        @JavascriptInterface
        public void keepOn(boolean on) {
            ui.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void share(String text) {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(i, "Поделиться")); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void copy(String text) {
            ui.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Neon Maps", text));
            });
        }

        @JavascriptInterface public void openUrl(String url) { ui.post(() -> openExternal(url)); }

        @JavascriptInterface
        public void dial(String phone) {
            ui.post(() -> {
                try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone.replaceAll("[^0-9+]", "")))); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public void toast(String t) { ui.post(() -> Toast.makeText(MainActivity.this, t, Toast.LENGTH_SHORT).show()); }

        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(Math.max(10, ms), VibrationEffect.DEFAULT_AMPLITUDE));
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public String takeIntent() { String t = pendingIntent; pendingIntent = ""; return t; }

        @JavascriptInterface public String regionStart(String json) { return regions.start(json); }
        @JavascriptInterface public void regionCancel(String id) { regions.cancel(id); }
        @JavascriptInterface public String regions() { return regions.list(); }
        @JavascriptInterface public void regionDelete(String id) { regions.delete(id); }
        @JavascriptInterface public String cacheInfo() { return store.info().toString(); }
        @JavascriptInterface public void cacheClear() { store.clearCache(); }
        @JavascriptInterface public String version() { return BuildConfig.VERSION_NAME; }
    }
}
