package app.neonmaps;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/** Offline areas: downloads every vector tile of a rectangle (zoom 0–14) into the pinned part of the tile store. */
final class Regions {
    static final int MAX_TILES = 3000;   // OpenFreeMap asks to keep single downloads small
    private final TileStore store;
    private final Geo.Out out;
    private final SharedPreferences prefs;
    private final ExecutorService jobs = Executors.newSingleThreadExecutor();
    private final Map<String, JSONObject> live = new ConcurrentHashMap<>();
    private final Map<String, Boolean> cancel = new ConcurrentHashMap<>();

    Regions(Context c, TileStore store, Geo.Out out) {
        this.store = store; this.out = out;
        prefs = c.getSharedPreferences("regions", Context.MODE_PRIVATE);
        // downloads interrupted by the app being closed
        JSONArray a = load();
        boolean changed = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject r = a.optJSONObject(i);
            if (r != null && ("run".equals(r.optString("status")) || "queued".equals(r.optString("status")))) { put(r, "status", "cancel"); changed = true; }
        }
        if (changed) save(a);
    }

    private static void put(JSONObject o, String k, Object v) { try { o.put(k, v); } catch (Exception ignored) { } }

    private synchronized JSONArray load() {
        try { return new JSONArray(prefs.getString("list", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    private synchronized void save(JSONArray a) { prefs.edit().putString("list", a.toString()).apply(); }

    private synchronized void upsert(JSONObject r) {
        JSONArray a = load(), n = new JSONArray();
        boolean found = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x == null) continue;
            if (x.optString("id").equals(r.optString("id"))) { n.put(r); found = true; } else n.put(x);
        }
        if (!found) n.put(r);
        save(n);
    }

    String list() {
        JSONArray a = load(), res = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x == null) continue;
            JSONObject l = live.get(x.optString("id"));
            res.put(l != null ? l : x);
        }
        return res.toString();
    }

    String start(String json) {
        try {
            JSONObject r = new JSONObject(json);
            String id = r.optString("id", "");
            if (id.isEmpty()) { id = "r" + System.currentTimeMillis(); r.put("id", id); }
            if (live.containsKey(id)) return id;
            r.put("status", "queued");
            r.put("ts", System.currentTimeMillis());
            upsert(r);
            live.put(id, r);
            cancel.remove(id);
            final String rid = id;
            jobs.execute(() -> run(rid, r));
            emit(r);
            return id;
        } catch (Exception e) { return ""; }
    }

    void cancel(String id) { cancel.put(id, true); }

    void delete(String id) {
        cancel.put(id, true);
        jobs.execute(() -> {
            store.unpinRegion(id);
            JSONArray a = load(), n = new JSONArray();
            for (int i = 0; i < a.length(); i++) { JSONObject x = a.optJSONObject(i); if (x != null && !x.optString("id").equals(id)) n.put(x); }
            save(n);
            live.remove(id);
        });
    }

    private void emit(JSONObject r) {
        try {
            JSONObject e = new JSONObject(r.toString());
            e.put("type", "region");
            out.emit(e);
        } catch (Exception ignored) { }
    }

    static int lat2y(double lat, int n) {
        double r = Math.toRadians(Math.max(-85.0511, Math.min(85.0511, lat)));
        return (int) Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * n);
    }

    static int lon2x(double lon, int n) { return (int) Math.floor((lon + 180) / 360 * n); }

    private void run(String id, JSONObject r) {
        put(r, "status", "run");
        double w = r.optDouble("w"), s = r.optDouble("s"), e = r.optDouble("e"), nn = r.optDouble("n");
        int maxz = Math.min(14, r.optInt("maxz", 14));
        List<String> urls = new ArrayList<>();
        String template;
        try {
            TileStore.Fetched f = TileStore.fetch(TileStore.TILEJSON, 15000);
            if (f.code != 200) throw new Exception("HTTP " + f.code);
            store.put("tilejson", f.data, "application/json", id);
            template = new JSONObject(new String(f.data, "UTF-8")).getJSONArray("tiles").getString(0);
        } catch (Exception ex) {
            put(r, "status", "error"); put(r, "error", "нет соединения с сервером карт");
            upsert(r); live.remove(id); emit(r); return;
        }
        for (int z = 0; z <= maxz; z++) {
            int n = 1 << z;
            int x0 = Math.max(0, lon2x(w, n)), x1 = Math.min(n - 1, lon2x(e, n)), y0 = Math.max(0, lat2y(nn, n)), y1 = Math.min(n - 1, lat2y(s, n));
            for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) {
                urls.add(template.replace("{z}", String.valueOf(z)).replace("{x}", String.valueOf(x)).replace("{y}", String.valueOf(y)));
                if (z <= 6) urls.add("https://tiles.openfreemap.org/natural_earth/ne2sr/" + z + "/" + x + "/" + y + ".png");
            }
        }
        if (urls.size() > MAX_TILES * 2) {
            put(r, "status", "error"); put(r, "error", "слишком большая область");
            upsert(r); live.remove(id); emit(r); return;
        }
        put(r, "total", urls.size());
        AtomicInteger done = new AtomicInteger(), failed = new AtomicInteger();
        AtomicLong bytes = new AtomicLong(), lastEmit = new AtomicLong();
        ExecutorService pool = Executors.newFixedThreadPool(4);
        for (String u : urls) pool.execute(() -> {
            if (cancel.containsKey(id)) return;
            String k = TileStore.key(u);
            try {
                if (store.has(k)) { store.pin(k, id); bytes.addAndGet(store.sizeOf(k)); }
                else {
                    TileStore.Fetched f = null;
                    for (int attempt = 0; attempt < 3; attempt++) {
                        try { f = TileStore.fetch(u, 25000); if (f.code == 200 || f.code == 404 || f.code == 204) break; } catch (Exception ex) { f = null; }
                        try { Thread.sleep(1500L * (attempt + 1)); } catch (InterruptedException ie) { return; }
                    }
                    if (f != null && f.code == 200) { store.put(k, f.data, TileStore.mime(u, f.ct), id); bytes.addAndGet(f.data.length); }
                    else if (f == null || (f.code != 404 && f.code != 204)) failed.incrementAndGet();
                }
            } catch (Exception ex) { failed.incrementAndGet(); }
            int d = done.incrementAndGet();
            long now = System.currentTimeMillis();
            if (now - lastEmit.get() > 400) {
                lastEmit.set(now);
                put(r, "done", d); put(r, "bytes", bytes.get());
                emit(r);
            }
        });
        pool.shutdown();
        try { while (!pool.awaitTermination(1, TimeUnit.SECONDS)) if (cancel.containsKey(id)) pool.shutdownNow(); } catch (InterruptedException ignored) { }
        put(r, "done", done.get());
        put(r, "bytes", store.regionBytes(id));
        put(r, "ts", System.currentTimeMillis());
        put(r, "status", cancel.containsKey(id) ? "cancel" : failed.get() > urls.size() / 50 ? "error" : "done");
        if (failed.get() > 0) put(r, "error", "не скачано фрагментов: " + failed.get());
        upsert(r);
        live.remove(id);
        emit(r);
    }
}
