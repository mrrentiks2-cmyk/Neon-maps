package app.neonmaps;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;

import org.json.JSONObject;

/** GPS / network location and compass heading, delivered to the page as events. */
final class Geo implements LocationListener, SensorEventListener {
    interface Out { void emit(JSONObject e); }

    private final Context ctx;
    private final Out out;
    private final LocationManager lm;
    private final SensorManager sm;
    private final Sensor rot;
    private boolean want, precise, wantCompass, paused, registered, compassOn;
    private long lastGps;
    private Location last;
    private final float[] rm = new float[9], rm2 = new float[9], orient = new float[3];
    private double az = -1, sentAz = -999;
    private long sentT;
    private GeomagneticField field;

    Geo(Context c, Out out) {
        this.ctx = c;
        this.out = out;
        lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        Sensor s = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (s == null && sm != null) s = sm.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR);
        rot = s;
    }

    boolean permitted() {
        return ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    boolean enabled() {
        try {
            if (Build.VERSION.SDK_INT >= 28) return lm.isLocationEnabled();
            return lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) { return true; }
    }

    /* ---------- lifecycle ---------- */
    void start(boolean precise) {
        boolean changed = !want || this.precise != precise;
        want = true; this.precise = precise;
        if (!paused && (changed || !registered)) register();
    }

    void stop() { want = false; unregister(); }

    void compass(boolean on) {
        wantCompass = on;
        if (on && !paused) compassStart(); else compassStop();
    }

    /** while navigating, GPS keeps running in the background (NavService keeps the app alive) */
    volatile boolean keepAlive;

    void pause() { paused = true; if (!keepAlive) unregister(); compassStop(); }

    void resume() { paused = false; if (want && !registered) register(); if (wantCompass) compassStart(); }

    private void register() {
        unregister();
        if (lm == null || !permitted()) return;
        boolean fine = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        try {
            if (fine && lm.getAllProviders().contains(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, precise ? 1000 : 2000, 0, this, Looper.getMainLooper());
            if (lm.getAllProviders().contains(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 4000, 0, this, Looper.getMainLooper());
            registered = true;
            // show something right away
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null && last == null) send(best, System.currentTimeMillis() - best.getTime() > 60000);
        } catch (SecurityException | IllegalArgumentException ignored) { }
    }

    private void unregister() {
        if (!registered || lm == null) return;
        try { lm.removeUpdates(this); } catch (Exception ignored) { }
        registered = false;
    }

    /* ---------- location ---------- */
    @Override
    public void onLocationChanged(Location l) {
        boolean gps = LocationManager.GPS_PROVIDER.equals(l.getProvider());
        long now = SystemClock.elapsedRealtime();
        if (gps) lastGps = now;
        else if (now - lastGps < 10000) return;   // keep using GPS while it is alive
        send(l, false);
    }

    private void send(Location l, boolean stale) {
        last = l;
        try {
            JSONObject e = new JSONObject();
            e.put("type", "loc");
            e.put("lat", l.getLatitude());
            e.put("lon", l.getLongitude());
            e.put("acc", l.hasAccuracy() ? Math.round(l.getAccuracy()) : 50);
            e.put("spd", l.hasSpeed() ? l.getSpeed() : 0);
            e.put("brg", l.hasBearing() && l.hasSpeed() && l.getSpeed() > 0.7 ? l.getBearing() : -1);
            if (l.hasAltitude()) e.put("alt", Math.round(l.getAltitude()));
            e.put("prov", l.getProvider());
            if (stale) e.put("stale", true);
            out.emit(e);
        } catch (Exception ignored) { }
        if (field == null || Math.abs(field.getDeclination()) < 0.0001 && l != null) {
            try { field = new GeomagneticField((float) l.getLatitude(), (float) l.getLongitude(), (float) l.getAltitude(), System.currentTimeMillis()); } catch (Exception ignored) { }
        }
    }

    @Override public void onStatusChanged(String p, int s, Bundle b) { }
    @Override public void onProviderEnabled(String p) { if (want && !paused) register(); }
    @Override public void onProviderDisabled(String p) { }

    /* ---------- compass ---------- */
    private void compassStart() {
        if (compassOn || rot == null) return;
        compassOn = sm.registerListener(this, rot, SensorManager.SENSOR_DELAY_UI);
    }

    private void compassStop() {
        if (!compassOn) return;
        sm.unregisterListener(this);
        compassOn = false;
    }

    @SuppressWarnings("deprecation")
    private int rotation() {
        try {
            Display d = ((WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
            return d.getRotation();
        } catch (Exception e) { return Surface.ROTATION_0; }
    }

    @Override
    public void onSensorChanged(SensorEvent ev) {
        SensorManager.getRotationMatrixFromVector(rm, ev.values);
        switch (rotation()) {
            case Surface.ROTATION_90: SensorManager.remapCoordinateSystem(rm, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, rm2); break;
            case Surface.ROTATION_180: SensorManager.remapCoordinateSystem(rm, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_MINUS_Y, rm2); break;
            case Surface.ROTATION_270: SensorManager.remapCoordinateSystem(rm, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, rm2); break;
            default: System.arraycopy(rm, 0, rm2, 0, 9);
        }
        SensorManager.getOrientation(rm2, orient);
        double deg = Math.toDegrees(orient[0]);
        if (field != null) deg += field.getDeclination();   // magnetic → true north
        deg = (deg + 360) % 360;
        if (az < 0) az = deg;
        else {
            double d = ((deg - az + 540) % 360) - 180;
            az = (az + d * 0.2 + 360) % 360;
        }
        long now = SystemClock.elapsedRealtime();
        double diff = Math.abs(((az - sentAz + 540) % 360) - 180);
        if (diff >= 1.5 && now - sentT >= 80) {
            sentAz = az; sentT = now;
            try { out.emit(new JSONObject().put("type", "heading").put("deg", Math.round(az * 10) / 10.0)); } catch (Exception ignored) { }
        }
    }

    @Override public void onAccuracyChanged(Sensor s, int a) { }
}
