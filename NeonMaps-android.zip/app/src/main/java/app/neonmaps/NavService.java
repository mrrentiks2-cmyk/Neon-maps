package app.neonmaps;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import java.lang.ref.WeakReference;

/**
 * Keeps navigation (GPS + voice prompts) alive when the screen is off or another app is open,
 * the same way Yandex Navigator does: a "navigation" notification while a route is active.
 */
public class NavService extends Service {
    static final String CH = "nav", ACT_STOP = "app.neonmaps.STOP_NAV", EXTRA_TEXT = "text";
    static final int NID = 7;
    static WeakReference<MainActivity> activity = new WeakReference<>(null);
    static volatile boolean running;

    static void start(Context c, String text) {
        Intent i = new Intent(c, NavService.class).putExtra(EXTRA_TEXT, text);
        try { c.startForegroundService(i); } catch (Exception ignored) { }
    }

    static void stop(Context c) {
        if (!running) return;
        c.stopService(new Intent(c, NavService.class));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACT_STOP.equals(intent.getAction())) {
            MainActivity a = activity.get();
            if (a != null) a.emitSimple("navStop");
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            running = false;
            return START_NOT_STICKY;
        }
        String text = intent != null ? intent.getStringExtra(EXTRA_TEXT) : null;
        Notification n = build(this, text == null || text.isEmpty() ? "Ведём по маршруту" : text);
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            else startForeground(NID, n);
            running = true;
        } catch (Exception e) {   // no location permission any more
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    /** new text in the ongoing notification (no service restart: allowed from the background) */
    static void update(Context c, String text) {
        if (!running) return;
        try { c.getSystemService(NotificationManager.class).notify(NID, build(c, text)); } catch (Exception ignored) { }
    }

    static Notification build(Context c, String text) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "Навигация", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Подсказки по маршруту, пока экран выключен");
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent pOpen = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pStop = PendingIntent.getService(c, 2, new Intent(c, NavService.class).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_nav)
                .setContentTitle("Neon Maps — навигация")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_NAVIGATION)
                .setContentIntent(pOpen)
                .addAction(new Notification.Action.Builder(null, "Завершить", pStop).build())
                .build();
    }

    @Override
    public void onDestroy() { running = false; super.onDestroy(); }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
