package app.neonmaps;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import org.json.JSONObject;

import java.util.Locale;

/** Russian voice prompts; music is ducked while a prompt is spoken. */
final class Speech implements TextToSpeech.OnInitListener {
    private final TextToSpeech tts;
    private final AudioManager am;
    private final Geo.Out out;
    private volatile String status = "init";
    private String pending;
    private int n;
    private AudioFocusRequest focus;
    private final AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();

    Speech(Context c, Geo.Out out) {
        this.out = out;
        am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        tts = new TextToSpeech(c.getApplicationContext(), this);
    }

    @Override
    public void onInit(int st) {
        if (st != TextToSpeech.SUCCESS) { status = "fail"; report(); return; }
        int r = tts.setLanguage(new Locale("ru", "RU"));
        status = r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED ? "nolang" : "ok";
        tts.setAudioAttributes(attrs);
        tts.setSpeechRate(1.05f);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { if (!tts.isSpeaking()) release(); }
            @Override @SuppressWarnings("deprecation") public void onError(String id) { release(); }
        });
        report();
        if (pending != null && "ok".equals(status)) { String p = pending; pending = null; say(p); }
    }

    private void report() {
        try { out.emit(new JSONObject().put("type", "tts").put("status", status)); } catch (Exception ignored) { }
    }

    String status() { return status; }

    synchronized void say(String text) {
        if (text == null || text.isEmpty()) return;
        if ("init".equals(status)) { pending = text; return; }
        if (!"ok".equals(status)) return;
        grab();
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + (++n));
    }

    void stop() { try { tts.stop(); } catch (Exception ignored) { } release(); }

    private void grab() {
        if (am == null) return;
        if (focus == null) focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attrs).build();
        am.requestAudioFocus(focus);
    }

    private void release() { if (am != null && focus != null) am.abandonAudioFocusRequest(focus); }

    void shutdown() { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) { } }
}
