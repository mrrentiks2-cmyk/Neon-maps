package app.neonmaps;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.webkit.WebResourceResponse;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/**
 * Map tile cache. Every tile, glyph and TileJSON the map needs goes through here:
 * served from the SQLite cache when present (offline), fetched and stored otherwise.
 * Tiles of downloaded regions are "pinned" and never trimmed.
 */
final class TileStore extends SQLiteOpenHelper {
    static final String UA = "NeonMaps/" + BuildConfig.VERSION_NAME + " (Android app; offline-capable map client)";
    static final long CACHE_LIMIT = 400L << 20, CACHE_TARGET = 300L << 20;
    static final long STALE_MS = 30L * 24 * 3600 * 1000;

    private static final Pattern OFM_TILE = Pattern.compile("^https://tiles\\.openfreemap\\.org/planet/[^/]+/(\\d+)/(\\d+)/(\\d+)\\.pbf$");
    private static final Pattern NE_TILE = Pattern.compile("^https://tiles\\.openfreemap\\.org/natural_earth/ne2sr/(\\d+)/(\\d+)/(\\d+)\\.png$");
    private static final Pattern SAT_TILE = Pattern.compile("^https://server\\.arcgisonline\\.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/(\\d+)/(\\d+)/(\\d+)$");
    static final String TILEJSON = "https://tiles.openfreemap.org/planet";

    private final File bigDir;
    private final ExecutorService bg = Executors.newFixedThreadPool(2);
    private final AtomicInteger puts = new AtomicInteger();
    private volatile boolean trimming;

    TileStore(Context c) {
        super(c, "tiles.db", null, 1);
        setWriteAheadLoggingEnabled(true);
        bigDir = new File(c.getFilesDir(), "tiles_big");
        //noinspection ResultOfMethodCallIgnored
        bigDir.mkdirs();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE t (k TEXT PRIMARY KEY, d BLOB, ct TEXT, ts INTEGER, pin INTEGER NOT NULL DEFAULT 0, sz INTEGER NOT NULL DEFAULT 0, big INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX t_lru ON t(pin, ts)");
        db.execSQL("CREATE TABLE rt (r TEXT NOT NULL, k TEXT NOT NULL, PRIMARY KEY (r, k))");
        db.execSQL("CREATE INDEX rt_k ON rt(k)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) { }

    /** stable cache key: tile URLs contain a weekly data version, the key does not */
    static String key(String url) {
        Matcher m = OFM_TILE.matcher(url);
        if (m.matches()) return "v/" + m.group(1) + "/" + m.group(2) + "/" + m.group(3);
        m = NE_TILE.matcher(url);
        if (m.matches()) return "ne/" + m.group(1) + "/" + m.group(2) + "/" + m.group(3);
        m = SAT_TILE.matcher(url);
        if (m.matches()) return "sat/" + m.group(1) + "/" + m.group(2) + "/" + m.group(3);
        if (url.equals(TILEJSON)) return "tilejson";
        return url;
    }

    static boolean allowedTile(String url) {
        return url.startsWith("https://tiles.openfreemap.org/") || url.startsWith("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/");
    }

    static boolean allowedApi(String url) {
        try {
            String h = new URL(url).getHost();
            return url.startsWith("https://") && (h.equals("photon.komoot.io") || h.equals("nominatim.openstreetmap.org") || h.equals("valhalla1.openstreetmap.de")
                    || h.equals("maps.mail.ru") || h.equals("overpass.private.coffee") || h.equals("overpass-api.de") || h.equals("tiles.openfreemap.org"));
        } catch (Exception e) { return false; }
    }

    static final class Entry {
        byte[] data; String ct; long ts; boolean pinned;
    }

    Entry get(String k) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT d, ct, ts, big, pin FROM t WHERE k=?", new String[]{k})) {
            if (!c.moveToFirst()) return null;
            Entry e = new Entry();
            e.ct = c.getString(1); e.ts = c.getLong(2); e.pinned = c.getInt(4) != 0;
            if (c.getInt(3) != 0) {
                File f = bigFile(k);
                if (!f.exists()) return null;
                e.data = Files.readAllBytes(f.toPath());
            } else e.data = c.getBlob(0);
            return e.data == null ? null : e;
        } catch (Exception ex) { return null; }
    }

    boolean has(String k) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM t WHERE k=?", new String[]{k})) { return c.moveToFirst(); }
        catch (Exception e) { return false; }
    }

    long sizeOf(String k) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT sz FROM t WHERE k=?", new String[]{k})) { return c.moveToFirst() ? c.getLong(0) : 0; }
        catch (Exception e) { return 0; }
    }

    private File bigFile(String k) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-1").digest(k.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format(Locale.ROOT, "%02x", b));
            return new File(bigDir, sb.toString());
        } catch (Exception e) { return new File(bigDir, Integer.toHexString(k.hashCode())); }
    }

    /** store; region != null pins the tile to that downloaded region */
    void put(String k, byte[] data, String ct, String region) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put("k", k); v.put("ct", ct); v.put("ts", System.currentTimeMillis()); v.put("sz", data.length);
            if (data.length > 900_000) {
                try (FileOutputStream o = new FileOutputStream(bigFile(k))) { o.write(data); }
                v.putNull("d"); v.put("big", 1);
            } else { v.put("d", data); v.put("big", 0); }
            boolean pinned = region != null;
            db.beginTransaction();
            try {
                Cursor c = db.rawQuery("SELECT pin FROM t WHERE k=?", new String[]{k});
                if (c.moveToFirst() && c.getInt(0) != 0) pinned = true;
                c.close();
                v.put("pin", pinned ? 1 : 0);
                db.insertWithOnConflict("t", null, v, SQLiteDatabase.CONFLICT_REPLACE);
                if (region != null) db.execSQL("INSERT OR IGNORE INTO rt(r, k) VALUES (?, ?)", new Object[]{region, k});
                db.setTransactionSuccessful();
            } finally { db.endTransaction(); }
            if (region == null && puts.incrementAndGet() % 60 == 0) trimLater();
        } catch (Exception ignored) { }
    }

    void pin(String k, String region) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            db.execSQL("INSERT OR IGNORE INTO rt(r, k) VALUES (?, ?)", new Object[]{region, k});
            db.execSQL("UPDATE t SET pin=1 WHERE k=?", new Object[]{k});
        } catch (Exception ignored) { }
    }

    void unpinRegion(String region) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            db.execSQL("DELETE FROM rt WHERE r=?", new Object[]{region});
            db.execSQL("UPDATE t SET pin=0, ts=0 WHERE pin=1 AND k NOT IN (SELECT k FROM rt)");
            trimLater();
        } catch (Exception ignored) { }
    }

    private void trimLater() {
        if (trimming) return;
        trimming = true;
        bg.execute(() -> {
            try {
                SQLiteDatabase db = getWritableDatabase();
                long total = 0;
                try (Cursor c = db.rawQuery("SELECT COALESCE(SUM(sz),0) FROM t WHERE pin=0", null)) { if (c.moveToFirst()) total = c.getLong(0); }
                boolean over = total > CACHE_LIMIT;
                while (over && total > CACHE_TARGET) {
                    long freed = 0;
                    try (Cursor c = db.rawQuery("SELECT k, sz, big FROM t WHERE pin=0 ORDER BY ts LIMIT 400", null)) {
                        db.beginTransaction();
                        try {
                            while (c.moveToNext()) {
                                String k = c.getString(0);
                                if (c.getInt(2) != 0) //noinspection ResultOfMethodCallIgnored
                                    bigFile(k).delete();
                                db.execSQL("DELETE FROM t WHERE k=?", new Object[]{k});
                                freed += c.getLong(1);
                                if (total - freed < CACHE_TARGET) break;
                            }
                            db.setTransactionSuccessful();
                        } finally { db.endTransaction(); }
                    }
                    if (freed == 0) break;
                    total -= freed;
                }
            } catch (Exception ignored) {
            } finally { trimming = false; }
        });
    }

    JSONObject info() {
        JSONObject o = new JSONObject();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT pin, COALESCE(SUM(sz),0), COUNT(*) FROM t GROUP BY pin", null)) {
            while (c.moveToNext()) {
                if (c.getInt(0) == 0) { o.put("cache", c.getLong(1)); o.put("cacheTiles", c.getLong(2)); }
                else { o.put("regions", c.getLong(1)); o.put("regionTiles", c.getLong(2)); }
            }
        } catch (Exception ignored) { }
        return o;
    }

    long regionBytes(String region) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(t.sz),0) FROM rt JOIN t ON t.k=rt.k WHERE rt.r=?", new String[]{region})) {
            return c.moveToFirst() ? c.getLong(0) : 0;
        } catch (Exception e) { return 0; }
    }

    void clearCache() {
        bg.execute(() -> {
            try {
                SQLiteDatabase db = getWritableDatabase();
                try (Cursor c = db.rawQuery("SELECT k FROM t WHERE pin=0 AND big=1", null)) {
                    while (c.moveToNext()) //noinspection ResultOfMethodCallIgnored
                        bigFile(c.getString(0)).delete();
                }
                db.execSQL("DELETE FROM t WHERE pin=0");
                db.execSQL("VACUUM");
            } catch (Exception ignored) { }
        });
    }

    /* ======================= network ======================= */
    static final class Fetched {
        int code; byte[] data = new byte[0]; String ct = "application/octet-stream";
    }

    static Fetched fetch(String url, int timeout) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(Math.min(timeout, 10000));
            c.setReadTimeout(timeout);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "*/*");
            c.setInstanceFollowRedirects(true);
            Fetched f = new Fetched();
            f.code = c.getResponseCode();
            String ct = c.getContentType();
            if (ct != null) f.ct = ct;
            InputStream in = f.code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) {
                byte[] raw = readAll(in);
                // some servers always send gzip; HttpURLConnection only unpacks what it asked for
                if (raw.length > 2 && (raw[0] & 0xff) == 0x1f && (raw[1] & 0xff) == 0x8b) {
                    try { raw = readAll(new GZIPInputStream(new ByteArrayInputStream(raw))); } catch (IOException ignored) { }
                }
                f.data = raw;
            }
            return f;
        } finally { c.disconnect(); }
    }

    static byte[] readAll(InputStream in) throws IOException {
        try (InputStream i = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[32768];
            int n;
            while ((n = i.read(b)) > 0) {
                bo.write(b, 0, n);
                if (bo.size() > (48 << 20)) throw new IOException("слишком большой ответ");
            }
            return bo.toByteArray();
        }
    }

    static String mime(String url, String ct) {
        if (url.endsWith(".pbf")) return "application/x-protobuf";
        if (url.endsWith(".png")) return "image/png";
        if (ct != null && !ct.isEmpty()) return ct.split(";")[0].trim();
        return "application/octet-stream";
    }

    static WebResourceResponse resp(int code, String mime, byte[] body) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-store");
        if (code >= 300 && code < 400) code = 502;
        if (code < 100 || code > 599) code = 502;
        String reason = code == 200 ? "OK" : code == 404 ? "Not Found" : code == 403 ? "Forbidden" : code == 504 ? "Gateway Timeout" : code == 502 ? "Bad Gateway" : code == 429 ? "Too Many Requests" : code < 300 ? "OK" : "Error";
        return new WebResourceResponse(mime, "utf-8", code, reason, h, new ByteArrayInputStream(body == null ? new byte[0] : body));
    }

    static WebResourceResponse jsonError(int code, String msg) {
        String j;
        try { j = new JSONObject().put("error", msg).toString(); } catch (Exception e) { j = "{}"; }
        return resp(code, "application/json", j.getBytes(StandardCharsets.UTF_8));
    }

    /** /__t?u=… : tiles, fonts, TileJSON */
    WebResourceResponse serve(String url) {
        if (url == null || !allowedTile(url)) return resp(403, "text/plain", null);
        String k = key(url);
        boolean tj = "tilejson".equals(k);
        Entry e = get(k);
        if (tj) {
            try {
                Fetched f = fetch(url, e != null ? 5000 : 12000);
                if (f.code == 200 && f.data.length > 0) { put(k, f.data, "application/json", e != null && e.pinned ? "tilejson" : null); return resp(200, "application/json", f.data); }
            } catch (IOException ignored) { }
            return e != null ? resp(200, "application/json", e.data) : jsonError(504, "offline");
        }
        if (e != null) {
            if (System.currentTimeMillis() - e.ts > STALE_MS) bg.execute(() -> refresh(url, k, e.pinned));
            return resp(200, mime(url, e.ct), e.data);
        }
        try {
            Fetched f = fetch(url, 20000);
            if (f.code == 200) { put(k, f.data, mime(url, f.ct), null); return resp(200, mime(url, f.ct), f.data); }
            if (f.code == 404 || f.code == 204) return resp(404, "text/plain", null);
            return resp(502, "text/plain", null);
        } catch (IOException ex) { return resp(504, "text/plain", null); }
    }

    private void refresh(String url, String k, boolean pinned) {
        try {
            Fetched f = fetch(url, 20000);
            if (f.code == 200 && f.data.length > 0) put(k, f.data, mime(url, f.ct), null);
        } catch (IOException ignored) { }
    }

    /** /__h?u=… : search and routing APIs (adds the User-Agent required by the OSM services) */
    WebResourceResponse proxy(String url) {
        if (url == null || !allowedApi(url)) return jsonError(403, "адрес не разрешён");
        try {
            Fetched f = fetch(url, 30000);
            return resp(f.code, mime(url, f.ct), f.data);
        } catch (java.net.SocketTimeoutException e) {
            return jsonError(504, "сервер не отвечает");
        } catch (IOException e) {
            return jsonError(502, "нет соединения");
        }
    }
}
